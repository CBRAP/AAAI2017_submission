# -*- coding: utf-8 -*-
'''Classes that implement various arms distributions'''

__author__ = "Olivier Cappé, Aurélien Garivier"
__version__ = "$Revision: 1.4 $"

