
Note 1:
__author__ = "Original version: Olivier Capp�, Aur�lien Garivier" http://perso.telecom-paristech.fr/~cappe/Code/
__revised author__ = "authors of a submission to AAAI2017"
__version__ = "$Revision: 1.00 $"

Note 2:
You can just open the demo.py file and run. Results are stored in the folder of `results'.

Note 3:
You can revise (policies = [SLUCB(K, data.nbfeatures), BallExplore(K, data.nbfeatures), CobraSG(K, data.nbfeatures), CobraRS(K, data.nbfeatures)]) for specific policy
You can revise (fbfile="simulation/fb.txt") and (ftfile="simulation/ft.txt") for datasets
You can revise (reductionVector = [10]) for different reduction dimension
