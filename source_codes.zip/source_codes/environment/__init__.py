# -*- coding: utf-8 -*-
'''Classes that implement some bandit settings (classical multi-armed bandits, linear bandits)'''

__author__ = "Olivier Cappé, Aurélien Garivier"
__version__ = "$Revision: 1.3 $"
