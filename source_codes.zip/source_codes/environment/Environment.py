# -*- coding: utf-8 -*-
'''Generic class for Environment, empty for the time being'''

__author__ = "Olivier Cappé, Aurélien Garivier"
__version__ = "$Revision: 1.6 $"


from Result import *

class Environment:
  def __init__(self): pass
