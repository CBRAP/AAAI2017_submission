# -*- coding: utf-8 -*-
'''Classes that implement various policies for multi-armed bandits'''


