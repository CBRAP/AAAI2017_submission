# -*- coding: utf-8 -*-
'''Classes that implement various policies for multi-armed bandits'''

__author__ = "Olivier Cappé, Aurélien Garivier"
__version__ = "$Revision: 1.4 $"

