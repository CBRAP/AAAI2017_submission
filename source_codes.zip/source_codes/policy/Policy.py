# -*- coding: utf-8 -*-
'''Generic policy.'''



class Policy:
    """Class that implements a generic policy class.
    void for the time being.
    """

#  def __init__(self): pass

#  def startGame(self, nbArms): pass

#  def choice(self): pass

#  def getReward(self): pass
