# -*- coding: utf-8 -*-
'''Classes for posterior distributions in Bayesian multi-armed bandit algorithms'''

__author__ = "Olivier Cappé, Aurélien Garivier"
__version__ = "$Revision: 1.3 $"
